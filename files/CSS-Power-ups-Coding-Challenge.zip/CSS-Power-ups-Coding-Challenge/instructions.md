# CSS Power-ups Coding Challenge

Your task is to implement the included mockup in HTML and CSS. You can use the
included index.html and style.css files as a starting point if you wish.

## Helpful hints

The font used in the mockup is Roboto, and is available on Google Fonts.

The icons in the mockup are from a set called Weather Icons, which is included
in the assets directory. Documentation for how to use the icons can be found at
http://erikflowers.github.io/weather-icons/.

These color codes may be helpful to you as well:

Coral Tree:       hsl(351, 26%, 52%)
Platinum:         hsl(37, 10%, 90%)

Silver Chalice:   hsl(93, 7%, 68%)
Gunsmoke:         hsl(90, 5%, 47%)
Rock:             hsl(50, 19%, 30%)

Can Can:          hsl(356, 44%, 73%)
Tapestry:         hsl(342, 37%, 53%)
Toledo:           hsl(314, 18%, 19%)
